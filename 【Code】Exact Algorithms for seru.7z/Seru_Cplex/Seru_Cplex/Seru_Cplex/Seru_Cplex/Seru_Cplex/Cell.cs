﻿using System.Collections.Generic;

namespace Seru_Cplex
{
    public class Cell
    {
        /************************************
        * workSet：工人集合-Seru构造
        * batchSet：批次集合-Seru调度
        * ThroughPutTime：当前通过时间
        * LaborTime：劳动时间
        * IdealThroughtPutTime：理想通过时间
        * BestThroughPutTime：最优通过时间
        ************************************/
        public List<string> workerSet = new List<string>();
        public List<string> batchSet = new List<string>();
        public double ThroughPutTime = new double();
        public double LaborTime = new double();
        public double IdealThroughtPutTime = new double();
        public double BestThroughPutTime = new double();
    }
}
