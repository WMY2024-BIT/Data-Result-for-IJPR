﻿using System.Collections.Generic;

namespace Seru_Cplex
{
    public class Solution
    {
        /*****************************************
        * cellSet：Seru单元集合
        * TotalThroughPutTime：总通过时间
        * TotalLaborTime：总劳动时间
        * idealTotalThroughPutTime：理想总通过时间
        ******************************************/
        public List<Cell> cellSet = new List<Cell>();
        public double TotalThroughPutTime = new double();
        public double TotalLaborTime = new double();
        public double idealTotalThroughPutTime = new double();
    }
}
