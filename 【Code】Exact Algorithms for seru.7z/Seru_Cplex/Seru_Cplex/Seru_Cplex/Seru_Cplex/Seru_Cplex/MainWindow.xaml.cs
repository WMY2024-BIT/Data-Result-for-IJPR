﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Text;
using System.Windows;

namespace Seru_Cplex
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        string strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\实验数据.xls;Extended Properties='Excel 12.0;HDR=yes;IMEX=1'";

        DataTable tableBatchToProductType = new DataTable();
        DataTable tableWorkerToProductType = new DataTable();
        DataTable tableWorkerToMultipleTask = new DataTable();
        //taskTime - 产品类型 n 在流水线上的平衡时间 
        double taskTime = 1.8;
        //maxNumOfMultipleTask - 工人在Seru中有效操作工序的上界
        int maxNumOfMultipleTask = 10;
        //定义工人与批次
        int numofmachines = 4;//直接确定需要构造的seru数量
        int numOfWorkers = 0;
        int batchesSize = 0;
        double budget = 0.5;//定义预算  02:54:35.2318320  01:13:30.8519917
        double optimalvalue = 1000000;
        public MainWindow()
        {
            InitializeComponent();
            readExcel();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DateTime beginTime = DateTime.Now;
            bool inputFlag = true;
            /*************
            * 输入工人数   
            * 输入批次数
            **************/
            try
            {
                numOfWorkers = Convert.ToInt32(textSayWorkerNum.Text.ToString());
                batchesSize = Convert.ToInt32(textSaybatchesNum.Text.ToString());
            }
            catch (System.Exception)
            {
                this.textSayInputError.Text = "输入错误！";
                inputFlag = false;
            }
            if (inputFlag)
            {
                for (int i = 1; i < numOfWorkers; i++)
                {
                    numofmachines = i;
                    double[,] wt = WorkerProcessTimeforwt(numOfWorkers, batchesSize);//计算工人加工每个产品批次的时间标称值[numOfWorkers, batchesSize] 
                    double[,] detaWtsj = WorkerProcessTimefordetasj(numOfWorkers, batchesSize);//计算工人加工每个产品批次的时间的最大偏差[numOfWorkers+1, batchesSize]
                    double[,] detaWtij = WorkerProcessTimefordetaij(numOfWorkers, batchesSize);//计算工人加工每个产品批次的时间的最大偏差[numOfWorkers, batchesSize]
                    double[,] deta_hatsj = Calculate_deta_hatsj(detaWtsj, budget, numOfWorkers, batchesSize);//计算deta_hat
                    double[,,] deta_mean = Calculate_deta_mean(detaWtij, detaWtsj, wt, numOfWorkers, batchesSize);//计算deta_mean
                    double[,] deta_max = Calculate_deta_max(deta_mean, numOfWorkers, batchesSize);//计算deta_max
                    double[] P_m_j_w = Calculate_P_m_j_w(numOfWorkers, batchesSize, tableBatchToProductType, wt, detaWtij);
                    double[] batchsizeRadicalsign = Calculate_batchsize_Radicalsign(tableBatchToProductType, batchesSize);

                    string workerprocessTimeDevirationhatsj = ConvertToString(deta_hatsj, numOfWorkers);
                    string workerprocessTimeDevirationmean = ArrayToString(deta_mean);
                    string workerprocessTimeDevirationdeta_max = ConvertToString(deta_max, numOfWorkers);
                    string workerprocessTimeP_m_j_w = ConvertToStringforonedimension(P_m_j_w);
                    string batchsize_Radicalsign = ConvertToStringforonedimension(batchsizeRadicalsign);

                    CplexSolver cplexSolver = new CplexSolver();
                    double MT = cplexSolver.showResult(numOfWorkers, numofmachines, batchesSize, workerprocessTimeDevirationhatsj, workerprocessTimeDevirationmean, workerprocessTimeDevirationdeta_max, workerprocessTimeP_m_j_w, batchsize_Radicalsign, optimalvalue);
                    Console.WriteLine(MT);
                    if (MT != 0)
                    {
                        if (optimalvalue > MT)
                        {
                            optimalvalue = MT;
                        }
                    }

                }
            }
            Console.WriteLine("*******************");
            Console.WriteLine(optimalvalue);
            DateTime endTime = DateTime.Now;
            TimeSpan timespan = endTime - beginTime;
            Console.WriteLine("时间：" + timespan);
            Console.ReadLine();
        }

        /// <summary>
        /// 计算batchsize_Radicalsign
        /// </summary>
        /// <param name="tableBatchToProductType"></param>
        /// <param name="batchesSize"></param>
        /// <returns></returns>
        public static double[] Calculate_batchsize_Radicalsign(DataTable tableBatchToProductType, int batchesSize)
        {
            double[] batchsize_Radicalsign = new double[batchesSize];
            for (int j = 0; j < batchesSize; j++)
            {
                int batchSize = Convert.ToInt16(tableBatchToProductType.Rows[j][2]);//获取每一批产品的size
                batchsize_Radicalsign[j] = Math.Round(Math.Sqrt(batchSize) * 4, 7);
            }
            return batchsize_Radicalsign;
        }


        /// <summary>
        /// 计算Calculate_P_m_j_w
        /// </summary>
        /// <returns></returns>
        public static double[] Calculate_P_m_j_w(int numOfWorkers, int batchesSize, DataTable tableBatchToProductType, double[,] wt, double[,] detaWt)
        {
            double[] P_m_j_w = new double[batchesSize];
            for (int j = 0; j < batchesSize; j++)//循环遍历每个批次
            {
                int batchSize = Convert.ToInt16(tableBatchToProductType.Rows[j][2]);//获取每一批产品的size
                double maxValue = 0;
                for (int i = 0; i < numOfWorkers; i++)
                {
                    if (maxValue < (wt[i, j] + detaWt[i, j]))
                    {
                        maxValue = Math.Round(wt[i, j] + detaWt[i, j], 7);
                    }
                }
                P_m_j_w[j] = Math.Round(maxValue * batchSize * 10000, 7);
            }
            return P_m_j_w;
        }

        /// <summary>
        /// 计算deta_hat
        /// </summary>
        /// <param name="detaWt"></param>
        /// <param name="budget"></param>
        /// <param name="numOfWorkers"></param>
        /// <param name="numOfbatches"></param>
        /// <returns></returns>
        public static double[,] Calculate_deta_hatsj(double[,] detaWtsj, double budget, int numOfWorkers, int numOfbatches)
        {
            double[,] deta_hat = new double[numOfWorkers + 1, numOfbatches];
            for (int i = 0; i <= numOfWorkers; i++)
            {
                for (int j = 0; j < numOfbatches; j++)
                {
                    deta_hat[i, j] = Math.Round(Math.Sqrt(Math.Sqrt(detaWtsj[i, j] * budget)), 7);//更新deta矩阵

                }
            }
            return deta_hat;
        }

        /// <summary>
        /// 计算deta_mean
        /// </summary>
        /// <param name="detaWt"></param>
        /// <param name="budget"></param>
        /// <param name="numOfWorkers"></param>
        /// <param name="numOfbatches"></param>
        /// <returns></returns>
        public static double[,,] Calculate_deta_mean(double[,] detaWtij, double[,] detaWtsj, double[,] Wt, int numOfWorkers, int numOfbatches)
        {
            double[,,] deta_meansij = new double[numOfWorkers + 1, numOfWorkers, numOfbatches];//构建三维数组sij[numOfWorkers + 1][numOfWorkers][numOfbatches]
            for (int s = 0; s <= numOfWorkers; s++)
            {
                for (int i = 0; i < numOfWorkers; i++)
                {
                    for (int j = 0; j < numOfbatches; j++)
                    {
                        double corrector = 0;
                        if (detaWtij[i, j] - detaWtsj[s, j] >= 0)
                        {
                            corrector = Math.Round(detaWtij[i, j] - detaWtsj[s, j], 7);
                        }
                        else
                        {
                            corrector = 0;
                        }
                        deta_meansij[s, i, j] = Math.Round(Math.Sqrt(Math.Sqrt(Wt[i, j] + corrector)), 7);
                    }
                }
            }
            return deta_meansij;//检验过没有问题
        }

        /// <summary>
        /// 计算Calculate_deta_max
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public static double[,] Calculate_deta_max(double[,,] deta_mean, int numOfWorkers, int numOfbatches)
        {
            double[,] deta_max = new double[numOfWorkers, numOfbatches];

            for (int i = 0; i < numOfWorkers; i++)
            {
                for (int j = 0; j < numOfbatches; j++)
                {
                    double maxValue = 0;
                    for (int s = 0; s <= numOfWorkers; s++)
                    {
                        if (deta_mean[s, i, j] > maxValue)
                        {
                            maxValue = deta_mean[s, i, j];
                        }

                    }
                    deta_max[i, j] = maxValue * 200;
                }
            }
            return deta_max;
        }

        private string ConvertToString(double[] d)
        {
            string result = "[";
            for (int j = 0; j < d.Length - 1; j++)
            {
                result += d[j].ToString();
                result += ",";
            }
            result += d[d.Length - 1].ToString();
            result += "]";
            return result;
        }
        void readExcel()
        {
            OleDbConnection conn = new OleDbConnection(strConn);
            OleDbDataAdapter myCommand1 = new OleDbDataAdapter("SELECT * FROM [批次与产品类型关系$]", strConn);
            OleDbDataAdapter myCommand2 = new OleDbDataAdapter("SELECT * FROM [工人与产品类型的熟练程度$]", strConn);
            OleDbDataAdapter myCommand3 = new OleDbDataAdapter("SELECT * FROM [多能工系数$]", strConn);
            myCommand1.Fill(tableBatchToProductType);
            myCommand2.Fill(tableWorkerToProductType);
            myCommand3.Fill(tableWorkerToMultipleTask);
        }
        /*************************************************
         * 函数：CalculateBatchFlowTime - 计算批次加工时间
         * 说明：对于批次 m 在 单元 j 上加工的时间
         * 输入：cell - 含有构造信息和调度信息的Seru单元 ：已知Seru构造，Xij = 1
         *       productTypeID - 产品的种类：已知产品类型，Vmn = 1
         *       batchSize - 批次规模
         * 输出：BatchFlowTime - 批次 m 在Seru中的加工时间
         *************************************************/
        public double CalculateBatchFlowTime(Cell cell, int productTypeID, int batchSize)
        {
            double batchFlowTime = 0;
            double TimeOfTheCellToOneProduct = 0;
            for (int j = 0; j < cell.workerSet.Count; j++)
            {
                int workerID = Convert.ToInt16(cell.workerSet[j].ToString());
                //MultipleCoefficient - 多能工系数，工人 i 操作多道工序时工作效率受到影响的水平
                double MultipleCoefficient = Convert.ToDouble(tableWorkerToMultipleTask.Rows[workerID - 1][1].ToString());
                //WorkerToProductTypeCoefficient - 工人 i 加工产品类型 n 的技术系数
                double WorkerToProductTypeCoefficient = Convert.ToDouble(tableWorkerToProductType.Rows[workerID - 1][productTypeID].ToString());
                double c = 1;
                //c - 工人在Seru中操作多个工序的能力系数
                if (numOfWorkers > maxNumOfMultipleTask)
                {
                    c = 1 + MultipleCoefficient * (numOfWorkers - maxNumOfMultipleTask);
                }
                //TimeOfTheCellToOneProduct - 批次 m 在所有工作台上的总加工时间
                TimeOfTheCellToOneProduct = TimeOfTheCellToOneProduct + taskTime * c * WorkerToProductTypeCoefficient;
            }
            //taskTimeInCell - 批次 m 在每个工作台上加工的平均时间
            double taskTimeInCell = TimeOfTheCellToOneProduct / cell.workerSet.Count;
            // batchFlowTime - 批次 m 在Seru中的加工时间
            batchFlowTime = taskTimeInCell * batchSize * numOfWorkers / cell.workerSet.Count;
            return batchFlowTime;
        }
        /***********************************************************************
        * 函数：ProduceProcessTime - 给定一个Seru构造，生成二维加工时间矩阵 
        * 输入：solution - 含有构造信息和调度信息的Seru单元，目前调度信息未知；
        *       枚举所有批次，获得所有批次在该构造上的加工时间
        * 输出：t[j, m] - 给定Seru构造，批次 m 在 单元 j 上的加工时间
        ************************************************************************/
        public double[,] ProduceProcessTime(Solution solution)
        {

            double[,] t = new double[solution.cellSet.Count, batchesSize];
            for (int j = 0; j < solution.cellSet.Count; j++)
            {
                Cell tempCell = solution.cellSet[j];
                for (int m = 0; m < batchesSize; m++)//逐个产品批次循环
                {
                    //产品批次
                    //int batchID = Convert.ToInt16(tableBatchToProductType.Rows[m][0]);
                    //产品类型
                    int productTypeID = Convert.ToInt16(tableBatchToProductType.Rows[m][1]);
                    //批次规模
                    int batchSize = Convert.ToInt16(tableBatchToProductType.Rows[m][2]);

                    double batchFlowTime = CalculateBatchFlowTime(tempCell, productTypeID, batchSize);
                    t[j, m] = batchFlowTime;

                }
            }
            return t;
        }
        /// <summary>
        /// 工人加工时间的最大波动[sj]
        /// </summary>
        /// <param name="numOfWorkers"></param>
        /// <param name="batchesSize"></param>
        /// <returns></returns>
        public double[,] WorkerProcessTimefordetasj(int numOfWorkers, int batchesSize)
        {
            double[,] t = new double[numOfWorkers + 1, batchesSize];
            //工人循环
            for (int i = 0; i <= numOfWorkers; i++)
            {
                //产品批次循环
                for (int j = 0; j < batchesSize; j++)
                {
                    if (i == 0)
                    {
                        t[i, j] = 0;
                        continue;
                    }
                    //批次ID
                    int productTypeID = Convert.ToInt16(tableBatchToProductType.Rows[j][1]);
                    //批次规模
                    int batchSize = Convert.ToInt16(tableBatchToProductType.Rows[j][2]);
                    int workerID = Convert.ToInt16((i).ToString());
                    //MultipleCoefficient - 多能工系数，工人 i 操作多道工序时工作效率受到影响的水平
                    double MultipleCoefficient = Convert.ToDouble(tableWorkerToMultipleTask.Rows[workerID - 1][1].ToString());
                    //WorkerToProductTypeCoefficient - 工人 i 加工产品类型 n 的技术系数
                    double WorkerToProductTypeCoefficient = Convert.ToDouble(tableWorkerToProductType.Rows[workerID - 1][productTypeID].ToString());
                    double c = 1;
                    //c - 工人在Seru中操作多个工序的能力系数
                    if (numOfWorkers > maxNumOfMultipleTask)
                    {
                        c = 1 + MultipleCoefficient * (numOfWorkers - maxNumOfMultipleTask);
                    }
                    //workerTime - 工人加工一个产品批次所用时间
                    double workerTime = taskTime * c * WorkerToProductTypeCoefficient * numOfWorkers;
                    t[i, j] = workerTime * 0.01;
                }
            }
            //for (int j = 0; j < batchesSize; j++)
            //{
            //    t[0, j] = t[1, j];
            //}
            return t;
        }


        /// <summary>
        /// 工人加工时间的最大波动[ij]
        /// </summary>
        /// <param name="numOfWorkers"></param>
        /// <param name="batchesSize"></param>
        /// <returns></returns>
        public double[,] WorkerProcessTimefordetaij(int numOfWorkers, int batchesSize)
        {
            double[,] t = new double[numOfWorkers, batchesSize];
            //工人循环
            for (int i = 0; i < numOfWorkers; i++)
            {
                //产品批次循环
                for (int j = 0; j < batchesSize; j++)
                {
                    //批次ID
                    int productTypeID = Convert.ToInt16(tableBatchToProductType.Rows[j][1]);
                    //批次规模
                    int batchSize = Convert.ToInt16(tableBatchToProductType.Rows[j][2]);
                    int workerID = Convert.ToInt16((i + 1).ToString());
                    //MultipleCoefficient - 多能工系数，工人 i 操作多道工序时工作效率受到影响的水平
                    double MultipleCoefficient = Convert.ToDouble(tableWorkerToMultipleTask.Rows[workerID - 1][1].ToString());
                    //WorkerToProductTypeCoefficient - 工人 i 加工产品类型 n 的技术系数
                    double WorkerToProductTypeCoefficient = Convert.ToDouble(tableWorkerToProductType.Rows[workerID - 1][productTypeID].ToString());
                    double c = 1;
                    //c - 工人在Seru中操作多个工序的能力系数
                    if (numOfWorkers > maxNumOfMultipleTask)
                    {
                        c = 1 + MultipleCoefficient * (numOfWorkers - maxNumOfMultipleTask);
                    }
                    //workerTime - 工人加工一个产品批次所用时间
                    double workerTime = taskTime * c * WorkerToProductTypeCoefficient * numOfWorkers;
                    t[i, j] = 0.03 * workerTime;
                }
            }
            return t;
        }
        /// <summary>
        /// 计算工人加工每个产品批次的时间标称值[numOfWorkers, batchesSize]
        /// </summary>
        /// <param name="numOfWorkers"></param>
        /// <param name="batchesSize"></param>
        /// <returns></returns>
        public double[,] WorkerProcessTimeforwt(int numOfWorkers, int batchesSize)
        {
            double[,] t = new double[numOfWorkers, batchesSize];
            //工人循环
            for (int i = 0; i < numOfWorkers; i++)
            {
                //产品批次循环
                for (int j = 0; j < batchesSize; j++)
                {
                    //批次ID
                    int productTypeID = Convert.ToInt16(tableBatchToProductType.Rows[j][1]);
                    //批次规模
                    int batchSize = Convert.ToInt16(tableBatchToProductType.Rows[j][2]);
                    int workerID = Convert.ToInt16((i + 1).ToString());
                    //MultipleCoefficient - 多能工系数，工人 i 操作多道工序时工作效率受到影响的水平
                    double MultipleCoefficient = Convert.ToDouble(tableWorkerToMultipleTask.Rows[workerID - 1][1].ToString());
                    //WorkerToProductTypeCoefficient - 工人 i 加工产品类型 n 的技术系数
                    double WorkerToProductTypeCoefficient = Convert.ToDouble(tableWorkerToProductType.Rows[workerID - 1][productTypeID].ToString());
                    double c = 1;
                    //c - 工人在Seru中操作多个工序的能力系数
                    if (numOfWorkers > maxNumOfMultipleTask)
                    {
                        c = 1 + MultipleCoefficient * (numOfWorkers - maxNumOfMultipleTask);
                    }
                    //workerTime - 工人加工一个产品批次所用时间
                    double workerTime = taskTime * c * WorkerToProductTypeCoefficient * numOfWorkers;
                    t[i, j] = workerTime;
                }
            }
            return t;
        }

        public string ConvertToStringforonedimension(double[] t)
        {
            string result = "[";
            //遍历每个单元，获取该单元对每个批次的加工时间
            for (int j = 0; j < t.Length; j++)
            {
                result += t[j].ToString();
                result += ",";
            }
            result = result.Remove(result.Length - 1, 1);
            result += "]";
            return result;
        }

        /****************************************************************************************************
        * 函数：ConvertToString - 将二维数组转化为字符串
        * 说明：   String 类型的变量，因此需要把 double[,] t —> string result
        * 输入：t[j, m] - 给定Seru构造，批次 m 在 单元 j 上的加工时间
        *       i - 给定Seru构造含有的单元数
        * 输出：result - 二维加工时间对应的字符串
        ******************************************************************************************************/
        public string ConvertToString(double[,] t, int i)
        {
            double a1 = t.GetLength(0);
            double a2 = t.GetLength(1);
            string result = "[";
            //遍历每个单元，获取该单元对每个批次的加工时间
            for (int j = 0; j < a1; j++)
            {
                result += "[";
                //.GetLength(int dimension)：获取指定维数的元素数
                for (int m = 0; m < t.GetLength(1) - 1; m++)
                {
                    result += t[j, m].ToString();
                    result += ",";
                }
                result += t[j, t.GetLength(1) - 1].ToString();
                result += "],";
            }
            result = result.Remove(result.Length - 1, 1);
            result += "]";
            return result;
        }

        /// <summary>
        /// 将三维数组转化为字符串
        /// </summary>
        /// <param name="t"></param>
        /// <param name="i"></param>
        /// <returns></returns>
        public static string ArrayToString(double[,,] array)
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("[");
            for (int i = 0; i < array.GetLength(0); i++)
            {
                if (i > 0)
                    sb.Append(", ");

                sb.Append("[");
                for (int j = 0; j < array.GetLength(1); j++)
                {
                    if (j > 0)
                        sb.Append(", ");

                    sb.Append("[");
                    for (int k = 0; k < array.GetLength(2); k++)
                    {
                        if (k > 0)
                            sb.Append(", ");

                        sb.Append(array[i, j, k].ToString("0.0000000"));
                    }
                    sb.Append("]");
                }
                sb.Append("]");
            }
            sb.Append("]");

            return sb.ToString();
        }
    }
}
