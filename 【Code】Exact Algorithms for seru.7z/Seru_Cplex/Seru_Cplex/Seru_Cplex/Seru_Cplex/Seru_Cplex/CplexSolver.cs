﻿using ILOG.CPLEX;
using ILOG.OPL;
using System;

namespace Seru_Cplex
{
    class CplexSolver
    {
        /*********************************************************
        * 函数： showResult - 利用模型文本生成Cplex模型，求解并显示求解结果
      
        * 输出： 显示目标函数值 - MakeSpan    
        *********************************************************/
        public double showResult(int numOfWorkers, int numofmachines, int batchesSize, string workerprocessTimeDevirationhatsj, string workerprocessTimeDevirationmean, string workerprocessTimeDevirationdeta_max, string workerprocessTimeP_m_j_w, string batchsize_Radicalsign, double optimalvalue)
        {
            double i = new double();
            int status = 127;
            try
            {
                OplFactory.DebugMode = true;
                OplFactory oplF = new OplFactory();
                OplErrorHandler errHandler = oplF.CreateOplErrorHandler(Console.Out);
                OplModelSource modelSource = oplF.CreateOplModelSourceFromString(GetModelText(numOfWorkers, numofmachines, batchesSize, workerprocessTimeDevirationhatsj, workerprocessTimeDevirationmean, workerprocessTimeDevirationdeta_max, workerprocessTimeP_m_j_w, batchsize_Radicalsign, optimalvalue), "MT");//建立的模型储存在GetModelText中
                OplSettings settings = oplF.CreateOplSettings(errHandler);
                OplModelDefinition def = oplF.CreateOplModelDefinition(modelSource, settings);
                Cplex cplex = oplF.CreateCplex();
                OplModel opl = oplF.CreateOplModel(def, cplex);
                opl.Generate();
                if (cplex.Solve())
                {
                    //先存储每次调用的目标函数值 没有存储对应解
                    i = opl.Cplex.ObjValue;
                    Console.Out.WriteLine("OBJECTIVE: " + opl.Cplex.ObjValue);
                    opl.PostProcess();
                    opl.PrintSolution(Console.Out);
                    status = 0;
                }
                else
                {
                    Console.Out.WriteLine("No solution!");
                    status = 1;
                }

                oplF.End();
            }
            catch (ILOG.OPL.OplException ex)
            {
                Console.WriteLine(ex.Message);
                status = 2;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                status = 3;
            }


            Environment.ExitCode = status;

            Console.WriteLine("--Press <Enter> to exit--");
            //Console.ReadLine();
            return i;
        }

        /// <summary>
        /// 建模函数
        /// </summary>
        /// <param name="numOfWorkers"></param>
        /// <param name="numofmachines"></param>
        /// <param name="batchesSize"></param>
        /// <param name="workerprocessingTime"></param>
        /// <param name="workerprocessTimeDeviration"></param>
        /// <param name="workerprocessTimeDevirationhat"></param>
        /// <param name="workerprocessTimeDevirationmean"></param>
        /// <param name="workerprocessTimeDevirationdeta_max"></param>
        /// <param name="workerprocessTimeP_m_j_w"></param>
        /// <param name="batchsize_Radicalsign"></param>
        /// <returns></returns>
        static String GetModelText(int numOfWorkers, int numofmachines, int batchesSize, string workerprocessTimeDevirationhatsj, string workerprocessTimeDevirationmean, string workerprocessTimeDevirationdeta_max, string workerprocessTimeP_m_j_w, String batchsize_Radicalsign, double bestResult)
        {
            String model = "";

            //直接确定需要构造的seru单元数量
            String stringMachines = "int nMachines =" + numofmachines + ";";
            model += stringMachines;
            //输入工人数量
            String stringWorkers = "int nWorkers =" + numOfWorkers + ";";
            model += stringWorkers;
            //自动修改批次数

            String stringBatches = "int nBatches =" + batchesSize + ";";
            model += stringBatches;


            model += "range Machines =1..nMachines;";

            model += "range Batches =1..nBatches;";
            model += "range Workers =1..nWorkers;";
            model += "range addMWorkers =0..nWorkers;";



            //自动修改processTime
            String string_workerprocessTimeDevirationhat = "float workerprocessTimeDevirationhat[addMWorkers][Batches]=" + workerprocessTimeDevirationhatsj + ";";
            model += string_workerprocessTimeDevirationhat;


            String string_workerprocessTimeDevirationmean = "float workerprocessTimeDevirationmean[addMWorkers][Workers][Batches]=" + workerprocessTimeDevirationmean + ";";
            model += string_workerprocessTimeDevirationmean;


            String string_workerprocessTimeDevirationdeta_max = "float workerprocessTimeDevirationdeta_max[Workers][Batches]=" + workerprocessTimeDevirationdeta_max + ";";
            model += string_workerprocessTimeDevirationdeta_max;


            String String_workerprocessTimeP_m_j_w = "float workerprocessTimeP_m_j_w[Batches]=" + workerprocessTimeP_m_j_w + ";";
            model += String_workerprocessTimeP_m_j_w;


            String String_batchsize_Radicalsign = "float batchsize_Radicalsign[Batches]=" + batchsize_Radicalsign + ";";
            model += String_batchsize_Radicalsign;


            String stringOptimalvalue = "float optimalvalue= " + bestResult + ";";
            model += stringOptimalvalue;


            //定义决策变量
            model += "dvar boolean X[Workers][Machines];";
            model += "dvar boolean Z[Machines][Batches];";
            model += "dvar float+ l[Machines][Batches];";
            model += "dvar float+ v[Machines][Batches];";
            model += "dvar float+ P[Machines][Batches];";
            model += "dvar float+ y[Workers][Machines][Batches];";
            model += "dvar float+ kesai[Workers][Machines][Batches];";
            model += "dvar int omega[addMWorkers][Machines][Batches];";
            model += "dvar int beta[Machines];";//辅助变量
            model += "dvar float+ Addomega[addMWorkers][Machines][Batches];";//float+类！！！
            model += "dvar float+ deta[addMWorkers][Batches];";//辅助变量（workerprocessTimeDevirationhat）
            model += "dvar float+ datamean[addMWorkers][Workers][Batches];";//辅助变量（workerprocessTimeDevirationmean）
            model += "dvar float+ datameanMax[Workers][Batches];";//辅助变量（workerprocessTimeDevirationdeta_max）
            model += "dvar float+  workerprocessTime[Batches];";//辅助变量（workerprocessTimeP_m_j_w）
            model += "dvar float+  batchsize_Radical[Batches];";//辅助变量（batchsize_Radicalsign）
            model += "dvar float+ CT;";


            model += "minimize  CT;";
            model += "subject to";//
            model += "{";

            model += "CT <= optimalvalue;";
            //8
            model += "  forall (m in Machines)";
            model += "    sum(i in Workers) X[i][m]>=1;";
            //7
            model += "  forall (i in Workers)";
            model += "    sum(m in Machines) X[i][m]==1;";
            //9
            model += "  forall (j in Batches)";
            model += "    sum(m in Machines) Z[m][j]==1;";

            //10
            model += "  forall (m in Machines)";
            model += "    CT>= sum(j in Batches) l[m][j];";

            //11
            model += "  forall (m in Machines)";
            model += "    forall (j in Batches)";
            model += "      l[m][j]<= workerprocessTimeP_m_j_w[j]*Z[m][j];";


            //12
            model += "  forall (m in Machines)";
            model += "    forall (j in Batches)";
            model += "      l[m][j]<= P[m][j];";


            //13
            model += "  forall (m in Machines)";
            model += "    forall (j in Batches)";
            model += "      l[m][j]>= P[m][j]-workerprocessTimeP_m_j_w[j]*(1-Z[m][j]);";


            //14
            model += "  forall (m in Machines)";
            model += "    forall (j in Batches)";
            model += "      l[m][j]>= 0;";


            //15(非法约束！！！)
            model += "  forall (m in Machines)";
            model += "    forall (j in Batches)";
            model += "     (P[m][j]+4)*(P[m][j]+4)>= sum(i in Workers) (batchsize_Radicalsign[j]*y[i][m][j]*batchsize_Radicalsign[j]*y[i][m][j])+ (batchsize_Radicalsign[j]*v[m][j]*batchsize_Radicalsign[j]*v[m][j])+(P[m][j]-4)*(P[m][j]-4);";


            //添加一条辅助约束：定义一下对x求和(辅助16)
            model += "  forall (m in Machines)";
            model += "    beta[m]==sum(i in Workers)X[i][m];";



            //16 这条约束被判定为非凸，怀疑求和出了问题(已解决，通过辅助约束16)
            model += "  forall (i in Workers)";
            model += "    forall (m in Machines)";
            model += "      forall (j in Batches)";
            model += "        (y[i][m][j]+beta[m])*(y[i][m][j]+beta[m])>= (kesai[i][m][j]*2)*(kesai[i][m][j]*2)+(y[i][m][j]-beta[m])*(y[i][m][j]-beta[m]);";


            //17 
            model += "  forall (i in Workers)";
            model += "    forall (m in Machines)";
            model += "      forall (j in Batches)";
            model += "        kesai[i][m][j] >= sum(s in addMWorkers)(workerprocessTimeDevirationmean[s][i][j]*omega[s][m][j])+ workerprocessTimeDevirationdeta_max[i][j]*(X[i][m]-1);";


            //18
            model += "  forall (i in Workers)";
            model += "    forall (m in Machines)";
            model += "      forall (j in Batches)";
            model += "        kesai[i][m][j] >= 0;";

            //辅助约束19(检查约束19是否发挥作用)
            model += "  forall (m in Machines)";
            model += "    forall (j in Batches)";
            model += "      forall (s in addMWorkers)";
            model += "        Addomega[s][m][j] == 2*workerprocessTimeDevirationhat[s][j]*omega[s][m][j]; ";



            //19
            model += "  forall (m in Machines)";
            model += "    forall (j in Batches)";
            model += "      (v[m][j]+beta[m])*(v[m][j]+beta[m]) >= (sum(s in addMWorkers)(Addomega[s][m][j])*(Addomega[s][m][j]))+(v[m][j]-beta[m])*(v[m][j]-beta[m]);";


            //20
            model += "  forall (m in Machines)";
            model += "    forall (j in Batches)";
            model += "      sum(s in addMWorkers)omega[s][m][j]==1;";


            //21
            model += "  forall (s in addMWorkers)";
            model += "    forall (m in Machines)";
            model += "      forall (j in Batches)";
            model += "        omega[s][m][j]>= 0;";


            //22
            model += "  forall (s in addMWorkers)";
            model += "    forall (m in Machines)";
            model += "      forall (j in Batches)";
            model += "        omega[s][m][j]<= 1;";


            //约束检验部分
            //打印数组workerprocessTimeDevirationhat
            model += "    forall (j in Batches)";
            model += "      forall (s in addMWorkers)";
            model += "      deta[s][j] == 1*workerprocessTimeDevirationhat[s][j]; ";
            //打印数组workerprocessTimeDevirationmean
            model += "  forall (s in addMWorkers)";
            model += "    forall (i in Workers)";
            model += "      forall (j in Batches)";
            model += "        datamean[s][i][j] == 1*workerprocessTimeDevirationmean[s][i][j]; ";
            //打印数组workerprocessTimeDevirationdeta_max
            model += "    forall (i in Workers)";
            model += "      forall (j in Batches)";
            model += "        datameanMax[i][j] == 1*workerprocessTimeDevirationdeta_max[i][j]; ";
            //打印数组workerprocessTimeP_m_j_w 
            model += "      forall (j in Batches)";
            model += "        workerprocessTime[j] == 1*workerprocessTimeP_m_j_w[j]; ";
            //打印数组batchsize_Radicalsign
            model += "      forall (j in Batches)";
            model += "        batchsize_Radical[j] == 1*batchsize_Radicalsign[j]; ";
            model += "}";
            return model;
        }
    }
}
