﻿using System.Collections.Generic;

namespace Seru_Cplex
{
    public class SeruStructure
    {
        /*************************************************
        * 函数：ProduceUnorderedDivisionList - 生成无序Seru构造集合
        * 说明：FirstCell - 第一个Seru单元
        *       FirstDivision - 第一个Seru构造
        *       nextWorker - 下一个待分配的工人
        *       Recurrence - 生成下一个Seru构造
        * 输入：group - 工人集合
        *       numOfWorkers - 工人数
        * 输出：UnorderedDivisionList - 无序Seru构造的集合
        ***************************************************/
        public List<List<List<string>>> ProduceUnorderedDivisionList(List<string> group, int numOfWorkers)
        {
            List<string> FirstCell = new List<string>();
            List<List<string>> FirstDivision = new List<List<string>>();
            List<List<List<string>>> UnorderedDivisionList = new List<List<List<string>>>();
            FirstCell.Add(group[0]);
            FirstDivision.Add(FirstCell);
            UnorderedDivisionList.Add(FirstDivision);
            //从第2个工人开始进行递推，生成下一个Seru构造
            for (int i = 1; i < numOfWorkers; i++)
            {
                string nextWorker = group[i];
                //每次递推都需要一个集合接收 numOfWorkers = n-1 时的Seru构造,以便利用此集合计算 numOfWorkers = n-1 时的Seru构造
                UnorderedDivisionList = Recurrence(UnorderedDivisionList, nextWorker);
            }
            return UnorderedDivisionList;
        }
        /*************************************************
        * 函数：Recurrence - 递推
        * 说明：i - Seru构造；j - Seru构造中的单元
               （1）利用递推生成一个Seru构造，穷举Seru构造属于无序集合划分；
               （2）递推关系：可以由 numOfWorkers = n-1 时的Seru构造情况推出 numOfWorkers = n 时的Seru构造情况
               （3）对于每一个Seru构造，当新加入一个工人 i 时，i 可以加入到任何一个Seru单元中，也可以自己单独构成一个Seru构造
        * 输入：DivisionList - Seru构造的集合
        *       nextWorker - 下一个待分配的工人
        * 输出：DivisionList - Seru构造集合
        ***************************************************/
        public List<List<List<string>>> Recurrence(List<List<List<string>>> unorderedDivisionList, string nextWorker)
        {
            List<List<List<string>>> UnorderedDivisionList = new List<List<List<string>>>();
            for (int i = 0; i < unorderedDivisionList.Count; i++)
            {
                //下一个Seru构造生成情况1：i 依次加入到每一个Seru单元中
                for (int j = 0; j < unorderedDivisionList[i].Count; j++)
                {
                    List<List<string>> DivisionClone = new List<List<string>>(unorderedDivisionList[i]);
                    //List<List<string>> DivisionClone = new List<List<string>>();
                    //DivisionClone = unorderedDivisionList[j];
                    List<string> CellClone = new List<string>(DivisionClone[j]);
                    //List<string> CellClone = new List<string>();
                    //CellClone = DivisionClone[j];
                    CellClone.Add(nextWorker);
                    //插入待分配工人到Seru单元中
                    DivisionClone.Insert(j, CellClone);
                    //删除原位置的Seru单元
                    DivisionClone.RemoveAt(j + 1);
                    UnorderedDivisionList.Add(DivisionClone);
                }
                //下一个Seru构造生成情况2：i 单独构成一个Seru构造
                List<string> CellSole = new List<string>()
                {
                    nextWorker
                };
                List<List<string>> NewDivision = new List<List<string>>(unorderedDivisionList[i]);
                NewDivision.Add(CellSole);
                UnorderedDivisionList.Add(NewDivision);
            }
            return UnorderedDivisionList;
        }
        /********************************************************
        * 函数：ProduceOrderedDivisionList - 生成有序Seru构造集合
        * 说明：usedDivision - 使用的Seru单元集合
        *       leftDivision - 未使用的Seru单元集合
        * 输入：Division - 无序Seru构造   
        * 输出：DivisionList - Seru构造集合
        ********************************************************/
        //public List<List<List<string>>> ProduceOrderedDivisionList( List<List<string>> Division )
        //{
        //    List<List<List<string>>> DivisionList = new List<List<List<string>>>();
        //    List<List<string>> usedDivision = new List<List<string>>();
        //    List<List<string>> leftDivision = new List<List<string>>();
        //    if (Division.Count == 1)
        //    {
        //        DivisionList.Add(Division);
        //    }
        //    else
        //    {
        //        for (int i = 0; i < Division.Count; i++)
        //        {
        //            List<List<string>> DivisionClone = new List<List<string>>(Division.ToArray());
        //            List<List<string>> usedDivisionClone = new List<List<string>>(usedDivision.ToArray());
        //            List<List<string>> leftDivisionClone = new List<List<string>>(leftDivision.ToArray());
        //            usedDivisionClone.Add(Division[i]);
        //            DivisionClone.RemoveAt(i);
        //            DivisionClone.ForEach(k => leftDivisionClone.Add(k));
        //            Recursion(DivisionList, usedDivisionClone, leftDivisionClone);
        //        }
        //    }
        //    return DivisionList;
        //}
        /********************************************************
        * 函数： Recursion - 递归
        * 说明：i - 未使用的Seru单元
                （1）过程：n 个单元的全排列 = 排好的第一位 +（n-1）个单元的全排列 = 排好的前两位 +（n-2）个单元的全排列…… + 最后一个单元
                （2）终止条件：leftinput.count==1
        * 输入：usedDivision - 使用的Seru单元集合
        *       leftDivision - 未使用的Seru单元集合   
        * 输出：DivisionList - Seru构造集合
        ********************************************************/
        //public List<List<List<string>>> Recursion(List<List<List<string>>> DivisionList, List<List<string>> usedDivision, List<List<string>> leftDivision)
        //{
        //    if (leftDivision.Count == 1)
        //    {
        //        usedDivision.Add(leftDivision[0]);
        //        DivisionList.Add(usedDivision);
        //    }
        //    else
        //    {
        //        for (int i = 0;i < leftDivision.Count;i++ )
        //        {
        //            List<List<string>> usedDivisionClone = new List<List<string>>(usedDivision);
        //            List<List<string>> leftDivisionClone = new List<List<string>>(leftDivision);
        //            usedDivisionClone.Add(leftDivisionClone[i]);
        //            leftDivisionClone.RemoveAt(i);
        //            //递归是不断的对问题进行降维,自己调用自己
        //            Recursion(DivisionList, usedDivisionClone, leftDivisionClone);
        //        }
        //    }
        //    return DivisionList;
        //}
    }
}
